% Question 2 - Lab exam 3
% SID: 460072429
% UniKey: xden2331
% Reset the workspace, command window, and figures
clc;
clear;

bouncingBallMovie();